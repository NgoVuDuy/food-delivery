<?php

namespace App\Repositories\Eloquent;

use App\Repositories\BaseRepository;
use App\Repositories\Interfaces\OptionRepositoryInterface;
use App\Models\Option;

class OptionRepository implements OptionRepositoryInterface {

}